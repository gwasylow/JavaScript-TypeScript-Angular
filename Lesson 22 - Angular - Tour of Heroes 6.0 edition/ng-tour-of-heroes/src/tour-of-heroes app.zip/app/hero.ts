
export class Hero {
    public id : number;
    public name : string;
}