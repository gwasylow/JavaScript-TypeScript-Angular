import { Component } from '@angular/core';

@Component({  //ng module
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Infosys';
}
